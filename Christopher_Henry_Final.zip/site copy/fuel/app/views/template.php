<html>
	<head>
		<title><?= isset($title) ? $title : 'Loelo House' ?></title>
	</head>

<?= $header ?>

<?= $content ?>

<?= $footer ?>