<div class="row">
    <div class="large-12 columns">
        <div id="artDisplay">
          <div>
            <img id="artDisplayImg" src="img/art/1.png"/>
            <a href="" id="back" class="left"><img src="img/arrow.png" border="0"/></a>
            <a href="" id="next" class="right"><img src="img/arrow2.png" border="0"/></a>
          </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="large-12 columns art_row">
        <ul id="thumbs">
          <li><a href="img/art/1.png"><img class="th art_thumb" src="img/thumbs/1.png"></a></li>
          <li><a href="img/art/2.png"><img class="th art_thumb" src="img/thumbs/2.png"></a></li>
          <li><a href="img/art/3.png"><img class="th art_thumb" src="img/thumbs/3.png"></a></li>
          <li><a href="img/art/4.png"><img class="th art_thumb" src="img/thumbs/4.png"></a></li>
        </ul>
    </div>
</div>