<div class="large-8 columns">
    <h2 class"blogtitle"><?= $post->title ?></h2>
    <p class="blogdescription"><?= $post->description ?></p>
    <p class="blogauthor">Date created: <?= $post->created_at ?>   Author: <?= $post->username ?></p>
</div>