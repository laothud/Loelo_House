<form method="post">
  <div class="row">
    <div class="large-12 columns">
      <label>Username: 
        <input name="username" type="text" placeholder="Username"/>
      </label>
    </div>
  </div>

  <div class="row">
    <div class="large-12 columns">
      <label>Password: 
        <input name="password" type="password"/>
      </label>
    </div>
  </div>

  <div class="row">
    <div class="large-12 columns">
      <input type="submit" class="button right" value="Login">
    </div>
  </div>

</form>