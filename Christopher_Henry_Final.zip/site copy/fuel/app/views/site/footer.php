<footer class="footer">
        <p>&copy;Christopher Henry 2014 Loelo House isn’t endorsed by Riot Games and doesn’t reflect the views or opinions of Riot Games or anyone officially involved in producing or managing League of Legends. League of Legends and Riot Games are trademarks or registered trademarks of Riot Games, Inc. League of Legends © Riot Games, Inc.</p>
    </footer>   

	<script src="http://localhost:9999/site/public/js/vendor/jquery.js"></script>
  <script src="http://localhost:9999/site/public/js/main.js"></script>
	<script src="http://localhost:9999/site/public/js/vendor/fastclick.js"></script>
    <script src="http://localhost:9999/site/public/js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>
</body>

</html>