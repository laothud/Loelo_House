<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-05-07 15:15:04 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.name' in 'field list' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`name` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`quote` AS `t0_c3` FROM `users` AS `t0` ORDER BY `t0`.`name` ASC" in /Applications/MAMP/htdocs/site/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-05-07 15:28:46 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.name' in 'field list' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`name` AS `t0_c1`, `t0`.`password` AS `t0_c2`, `t0`.`quote` AS `t0_c3` FROM `users` AS `t0` ORDER BY `t0`.`name` ASC" in /Applications/MAMP/htdocs/site/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-05-07 15:31:44 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.title' in 'field list' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`title` AS `t0_c1`, `t0`.`description` AS `t0_c2`, `t0`.`userid` AS `t0_c3`, `t0`.`created_at` AS `t0_c4`, `t0`.`username` AS `t0_c5` FROM `_users` AS `t0` ORDER BY `t0`.`created_at` DESC" in /Applications/MAMP/htdocs/site/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-05-07 16:04:11 --> 3 - Username already exists in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 251
ERROR - 2014-05-07 16:04:35 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-07 16:05:48 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-07 16:07:23 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-07 16:08:23 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-07 16:10:17 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-07 16:11:13 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
