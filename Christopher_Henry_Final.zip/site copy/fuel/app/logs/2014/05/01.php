<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-05-01 18:20:41 --> Fatal Error - Class 'Model\Posts' not found in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/home.php on line 17
ERROR - 2014-05-01 18:22:22 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/model/posts.php on line 10
ERROR - 2014-05-01 18:22:31 --> Fatal Error - Class 'Model\Posts' not found in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/home.php on line 17
ERROR - 2014-05-01 18:24:27 --> Parsing Error - syntax error, unexpected 'extends' (T_EXTENDS), expecting \\ (T_NS_SEPARATOR) or ';' or '{' in /Applications/MAMP/htdocs/site/fuel/app/classes/model/posts.php on line 3
ERROR - 2014-05-01 18:29:42 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-01 18:42:09 --> Fatal Error - Class 'Model_Posts' not found in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/home.php on line 12
ERROR - 2014-05-01 18:42:15 --> Error - SQLSTATE[42S02]: Base table or view not found: 1146 Table 'loelohouse.blogposts' doesn't exist with query: "SELECT `title`, `description` FROM `blogposts`" in /Applications/MAMP/htdocs/site/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-05-01 18:43:17 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.date' in 'field list' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`title` AS `t0_c1`, `t0`.`description` AS `t0_c2`, `t0`.`userid` AS `t0_c3`, `t0`.`date` AS `t0_c4` FROM `posts` AS `t0` ORDER BY `t0`.`date` DESC" in /Applications/MAMP/htdocs/site/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-05-01 19:21:33 --> Parsing Error - syntax error, unexpected end of file in /Applications/MAMP/htdocs/site/fuel/app/views/site/index.php on line 32
ERROR - 2014-05-01 19:21:58 --> Error - Property "name" not found for Model_Post. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-01 19:21:58 --> Error - Property "name" not found for Model_Post. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-01 19:28:46 --> Error - Property "name" not found for Model_Post. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-01 19:28:48 --> Error - Property "name" not found for Model_Post. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-01 19:28:48 --> Error - Property "name" not found for Model_Post. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-01 19:28:48 --> Error - Property "name" not found for Model_Post. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-01 19:28:48 --> Error - Property "name" not found for Model_Post. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-01 19:28:48 --> Error - Property "name" not found for Model_Post. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-01 19:40:03 --> Parsing Error - syntax error, unexpected '->' (T_OBJECT_OPERATOR) in /Applications/MAMP/htdocs/site/fuel/app/views/site/index.php on line 29
