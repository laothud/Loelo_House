<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-05-13 18:48:56 --> Fatal Error - Class 'Model_Video' not found in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 68
ERROR - 2014-05-13 18:49:19 --> Error - Property "artcode" not found for Model_Video. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-13 18:50:40 --> Notice - Undefined variable: videos in /Applications/MAMP/htdocs/site/fuel/app/views/site/admin_video.php on line 26
