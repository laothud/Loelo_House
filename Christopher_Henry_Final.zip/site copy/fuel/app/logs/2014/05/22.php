<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-05-22 17:23:45 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-22 17:36:33 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-22 17:41:20 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'title' cannot be null with query: "INSERT INTO `posts` (`title`, `description`, `userid`, `created_at`, `username`) VALUES (null, null, '8', '2014-05-22 17:41:20', 'Laothud')" in /Applications/MAMP/htdocs/site/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-05-22 17:44:35 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1452 Cannot add or update a child row: a foreign key constraint fails (`loelohouse`.`posts`, CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `_users` (`id`)) with query: "INSERT INTO `posts` (`title`, `description`, `userid`, `created_at`, `username`) VALUES ('Testing User post', 'Test good', '8', '2014-05-22 17:44:35', 'Laothud')" in /Applications/MAMP/htdocs/site/fuel/core/classes/database/pdo/connection.php on line 234
ERROR - 2014-05-22 17:48:40 --> Notice - Undefined variable: arts in /Applications/MAMP/htdocs/site/fuel/app/views/site/user_dash.php on line 90
ERROR - 2014-05-22 17:59:48 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
