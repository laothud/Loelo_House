<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-05-09 00:02:55 --> Parsing Error - syntax error, unexpected ';' in /Applications/MAMP/htdocs/site/fuel/app/views/site/header.php on line 81
