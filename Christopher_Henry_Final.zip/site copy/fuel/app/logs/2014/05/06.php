<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-05-06 17:37:08 --> Parsing Error - syntax error, unexpected 'echo' (T_ECHO) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/login.php on line 15
ERROR - 2014-05-06 17:37:20 --> Parsing Error - syntax error, unexpected 'echo' (T_ECHO) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/login.php on line 15
ERROR - 2014-05-06 17:37:32 --> Parsing Error - syntax error, unexpected 'echo' (T_ECHO) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/login.php on line 15
ERROR - 2014-05-06 17:37:43 --> Parsing Error - syntax error, unexpected 'echo' (T_ECHO) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/login.php on line 15
ERROR - 2014-05-06 18:02:33 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 29
ERROR - 2014-05-06 18:02:34 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 29
ERROR - 2014-05-06 18:03:38 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 29
ERROR - 2014-05-06 18:04:00 --> Fatal Error - Class 'Auth' not found in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 12
ERROR - 2014-05-06 18:05:54 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-06 18:08:20 --> Notice - Undefined offset: 0 in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 35
ERROR - 2014-05-06 18:09:40 --> Parsing Error - syntax error, unexpected '9999' (T_LNUMBER), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 35
ERROR - 2014-05-06 18:12:04 --> Notice - Trying to get property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 35
ERROR - 2014-05-06 18:14:05 --> Notice - Undefined variable: users in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 34
ERROR - 2014-05-06 18:14:28 --> Notice - Trying to get property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 38
ERROR - 2014-05-06 18:16:23 --> Notice - Trying to get property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 39
ERROR - 2014-05-06 18:16:33 --> Notice - Trying to get property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 39
ERROR - 2014-05-06 18:17:21 --> Notice - Use of undefined constant name - assumed 'name' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 39
ERROR - 2014-05-06 18:17:32 --> Notice - Use of undefined constant username - assumed 'username' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 39
ERROR - 2014-05-06 18:17:44 --> Notice - Trying to get property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 39
ERROR - 2014-05-06 18:32:39 --> Error - Property "username" not found for Model_User. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-06 18:33:28 --> Error - View variable is not set: content in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 430
ERROR - 2014-05-06 18:33:42 --> Error - View variable is not set: content in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 430
ERROR - 2014-05-06 18:35:27 --> Parsing Error - syntax error, unexpected 'if' (T_IF) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 37
ERROR - 2014-05-06 18:35:37 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 43
ERROR - 2014-05-06 18:35:46 --> Fatal Error - Call to undefined function push() in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 40
ERROR - 2014-05-06 18:36:33 --> Notice - Array to string conversion in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-06 18:49:23 --> Notice - Undefined variable: posts in /Applications/MAMP/htdocs/site/fuel/app/views/site/admin_dash.php on line 38
ERROR - 2014-05-06 19:08:25 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-06 19:09:05 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-06 19:09:20 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-06 19:10:13 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-06 19:10:35 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
