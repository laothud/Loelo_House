<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-05-15 17:28:51 --> Parsing Error - syntax error, unexpected '3' (T_LNUMBER), expecting ')' in /Applications/MAMP/htdocs/site/fuel/app/classes/model/user.php on line 63
ERROR - 2014-05-15 18:07:57 --> Compile Error - Can't use function return value in write context in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 44
ERROR - 2014-05-15 18:08:52 --> Parsing Error - syntax error, unexpected '{' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 55
ERROR - 2014-05-15 18:09:52 --> Error - Invalid method: Auth\Auth::login in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth.php on line 348
ERROR - 2014-05-15 18:10:41 --> Warning - Creating default object from empty value in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 55
ERROR - 2014-05-15 18:12:49 --> Fatal Error - Class 'Object' not found in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 55
ERROR - 2014-05-15 18:13:07 --> Warning - Attempt to assign property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 56
ERROR - 2014-05-15 18:13:53 --> Runtime Notice - Non-static method Model_User::newuser() should not be called statically, assuming $this from incompatible context in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 60
ERROR - 2014-05-15 18:19:48 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 65
ERROR - 2014-05-15 18:49:18 --> Parsing Error - syntax error, unexpected 'public' (T_PUBLIC) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 74
ERROR - 2014-05-15 18:50:30 --> Parsing Error - syntax error, unexpected 'public' (T_PUBLIC) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 74
ERROR - 2014-05-15 18:50:31 --> Parsing Error - syntax error, unexpected 'public' (T_PUBLIC) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 74
ERROR - 2014-05-15 18:51:26 --> Parsing Error - syntax error, unexpected 'public' (T_PUBLIC) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 74
ERROR - 2014-05-15 18:52:11 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-15 18:53:55 --> Compile Error - Can't use method return value in write context in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 26
ERROR - 2014-05-15 18:58:47 --> Fatal Error - Class 'Messages' not found in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 79
ERROR - 2014-05-15 19:14:43 --> 5 - Username cannot be changed. in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 328
ERROR - 2014-05-15 19:15:51 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 69
ERROR - 2014-05-15 19:16:20 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:20:48 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:21:37 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:23:24 --> Fatal Error - Class 'Messages' not found in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/auth.php on line 79
ERROR - 2014-05-15 19:24:21 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
ERROR - 2014-05-15 19:33:12 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:33:34 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:34:49 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:35:31 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:36:46 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:37:36 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 68
ERROR - 2014-05-15 19:37:45 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 68
ERROR - 2014-05-15 19:37:54 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 68
ERROR - 2014-05-15 19:37:55 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/admin.php on line 68
ERROR - 2014-05-15 19:38:17 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:40:18 --> Error - Property "quote" not found for Model_User. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-15 19:40:18 --> Error - Property "quote" not found for Model_User. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-15 19:40:18 --> Error - Property "quote" not found for Model_User. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-15 19:40:27 --> Error - Property "quote" not found for Model_User. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-15 19:40:55 --> Error - Property "quote" not found for Model_User. in /Applications/MAMP/htdocs/site/fuel/packages/orm/classes/model.php on line 1134
ERROR - 2014-05-15 19:45:13 --> Error - Old password is invalid in /Applications/MAMP/htdocs/site/fuel/packages/auth/classes/auth/login/ormauth.php on line 335
ERROR - 2014-05-15 19:51:13 --> Notice - Undefined variable: content in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 8
