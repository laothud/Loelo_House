<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-04-23 20:49:16 --> Error - date_default_timezone_get(): It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected the timezone 'UTC' for now, but please set date.timezone to select your timezone. in /Applications/MAMP/htdocs/site/fuel/core/classes/fuel.php on line 161
ERROR - 2014-04-23 17:04:16 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/site.php on line 5
ERROR - 2014-04-23 17:04:47 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/site.php on line 5
ERROR - 2014-04-23 17:30:19 --> Parsing Error - syntax error, unexpected '}', expecting ',' or ';' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/site.php on line 7
