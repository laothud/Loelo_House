<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

ERROR - 2014-04-29 18:22:35 --> Parsing Error - syntax error, unexpected '}' in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/home.php on line 12
ERROR - 2014-04-29 18:22:58 --> Parsing Error - syntax error, unexpected 'funcction' (T_STRING), expecting variable (T_VARIABLE) in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/app.php on line 5
ERROR - 2014-04-29 18:23:24 --> Warning - Attempt to assign property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/app.php on line 6
ERROR - 2014-04-29 18:24:30 --> Error - The requested view could not be found: site/home in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:24:51 --> Warning - Attempt to assign property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/home.php on line 7
ERROR - 2014-04-29 18:26:17 --> Warning - Attempt to assign property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/app.php on line 6
ERROR - 2014-04-29 18:27:04 --> Warning - Attempt to assign property of non-object in /Applications/MAMP/htdocs/site/fuel/app/classes/controller/app.php on line 6
ERROR - 2014-04-29 18:29:15 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:31:02 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:31:03 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:31:03 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:31:03 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:31:04 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:31:04 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:31:04 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:32:03 --> Error - The requested view could not be found: template in /Applications/MAMP/htdocs/site/fuel/core/classes/view.php on line 388
ERROR - 2014-04-29 18:35:40 --> Notice - Undefined variable: title in /Applications/MAMP/htdocs/site/fuel/app/views/template.php on line 3
