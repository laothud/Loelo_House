<?php
return array(
	'crypto_key' => 'h5474807oBNcSGw_oUb6I9M0',
	'crypto_iv' => 'SqQDX8EY0nWMTzgWi0upcIkg',
	'crypto_hmac' => 'Y10GvgqbwfPUPOER2kar4VhY',
);
